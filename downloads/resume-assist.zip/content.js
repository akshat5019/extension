(() => {
  // src/forms.js
  var normalize = (text) => String(text || "").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_-]/g, " ").toLowerCase().replace(/\s+/g, " ").trim();
  function classifyField(text, autocomplete = "", type = "") {
    const label = normalize(text);
    if (/password|captcha|one time|verification code|social security|passport|bank|credit card|date of birth|birth date/.test(label)) return null;
    if (/authorized|authorised|authorization|authorisation|sponsor|visa|salary|compensation|gender|race|ethnic|disabilit|veteran|pronoun|relocat|notice period|start date|years|experience|cover letter|why |agree|consent|citizen/.test(label)) return null;
    const auto = {
      "given-name": "firstName",
      "family-name": "lastName",
      name: "fullName",
      email: "email",
      tel: "phone",
      "street-address": "address",
      "address-line1": "address",
      "address-level2": "city",
      "address-level1": "state",
      "postal-code": "postalCode",
      "country-name": "country",
      country: "country",
      organization: "currentCompany",
      "organization-title": "jobTitle"
    };
    const token = autocomplete.split(/\s+/).at(-1);
    if (auto[token]) return auto[token];
    const patterns = [
      ["firstName", /\b(first|given|forename)\s*(name)?\b/],
      ["lastName", /\b(last|family|sur)\s*name\b/],
      ["fullName", /\b(full name|your name|legal name|candidate name)\b|^name$/],
      ["email", /\be ?mail\b/],
      ["phone", /\b(phone|mobile|telephone|contact number)\b/],
      ["linkedin", /linked\s?in/],
      ["github", /github/],
      ["website", /\b(website|portfolio|personal url)\b/],
      ["postalCode", /\b(zip|postal|pin code|pincode)\b/],
      ["city", /\b(city|town)\b/],
      ["state", /\b(state|province|region)\b/],
      ["country", /\bcountry\b/],
      ["address", /\b(street address|address line 1|address1)\b|^address$/],
      ["currentCompany", /\b(current company|current employer|company name|employer name)\b/],
      ["jobTitle", /\b(current title|current job title|job title|position title)\b/],
      ["school", /\b(school|university|college|institution)\b/],
      ["degree", /\bdegree\b/],
      ["skills", /\bskills\b/]
    ];
    for (const [key, regex] of patterns) if (regex.test(label)) return key;
    if (type === "email") return "email";
    if (type === "tel") return "phone";
    return null;
  }
  function profileValue(profile, key) {
    if (key === "fullName") return [profile.firstName, profile.lastName].filter(Boolean).join(" ");
    return profile[key] || "";
  }
  function describeField(element) {
    const doc = element.ownerDocument;
    const labels = Array.from(element.labels || []).map((label2) => label2.textContent.trim()).filter(Boolean);
    const ariaLabels = (element.getAttribute("aria-labelledby") || "").split(/\s+/).map((id) => doc.getElementById(id)?.textContent || "").filter(Boolean);
    const visibleLabel = labels.join(" ") || ariaLabels.join(" ") || element.getAttribute("aria-label") || element.getAttribute("placeholder");
    const fallback = element.name || element.id || element.getAttribute("autocomplete") || element.type;
    const label = String(visibleLabel || fallback || "Unlabelled field").replace(/\s+/g, " ").trim().slice(0, 240);
    return { label, key: classifyField(visibleLabel || fallback, element.autocomplete, element.type) };
  }
  function collectFields(doc) {
    return Array.from(doc.querySelectorAll("input,select,textarea")).filter((el) => {
      if (el.disabled || el.readOnly || el.closest("[hidden],[inert]") || ["hidden", "submit", "button", "reset", "image", "password"].includes(el.type)) return false;
      const style = doc.defaultView.getComputedStyle(el);
      return style.display !== "none" && style.visibility !== "hidden" && el.getClientRects().length > 0;
    });
  }
  function fieldValue(element) {
    if (["radio", "checkbox"].includes(element.type)) return element.checked ? element.value || "checked" : "";
    if (element.type === "file") return element.files?.length ? "Attached" : "";
    return element.value || "";
  }
  function isRequired(element) {
    return element.required || element.getAttribute("aria-required") === "true" || /\*|\(required\)/i.test(describeField(element).label);
  }
  function writeField(element, value) {
    if (!value || ["file", "checkbox", "radio", "password"].includes(element.type)) return false;
    if (element.tagName === "SELECT") {
      if (element.multiple) return false;
      const match = Array.from(element.options).find((option) => !option.disabled && option.value && (normalize(option.value) === normalize(value) || normalize(option.textContent) === normalize(value)));
      if (!match) return false;
      value = match.value;
    }
    const win = element.ownerDocument.defaultView;
    const prototype = element.tagName === "SELECT" ? win.HTMLSelectElement.prototype : element.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(prototype, "value").set.call(element, value);
    element.dispatchEvent(new win.Event("input", { bubbles: true }));
    element.dispatchEvent(new win.Event("change", { bubbles: true }));
    return element.value === value;
  }

  // src/submission.js
  var visible = (el) => el.getClientRects().length > 0 && el.ownerDocument.defaultView.getComputedStyle(el).visibility !== "hidden";
  function findScope(doc) {
    const fields = collectFields(doc);
    const groups = /* @__PURE__ */ new Map();
    for (const field of fields) {
      const scope = field.closest('[role="dialog"],dialog') || field.form;
      if (scope) groups.set(scope, (groups.get(scope) || 0) + 1);
    }
    const ordered = [...groups].sort((a, b) => b[1] - a[1]);
    if (!ordered.length || ordered[1] && ordered[0][1] === ordered[1][1]) return null;
    return ordered[0][0];
  }
  function submissionReadiness(doc, scope, allowOptionalBlanks = false) {
    if (!scope?.isConnected) return { ready: false, reason: "Application changed. Scan this step again." };
    const fields = collectFields(doc).filter((el) => scope.contains(el));
    if (!fields.length) return { ready: false, reason: "No application fields found. Open the application directly." };
    const missing = [];
    for (const field of fields) {
      const required = isRequired(field);
      let value = fieldValue(field);
      if (field.type === "radio" && field.name) {
        const group = fields.filter((el) => el.type === "radio" && el.name === field.name && el.form === field.form);
        value = group.some((el) => el.checked) ? "Selected" : "";
        if (missing.some((item) => item.radioGroup === field.name)) continue;
      }
      if (!value && (required || !allowOptionalBlanks)) missing.push({ label: describeField(field).label, radioGroup: field.type === "radio" ? field.name : null });
      else if (field.willValidate && !field.checkValidity()) missing.push({ label: `${describeField(field).label} (invalid)` });
    }
    if (missing.length) return { ready: false, reason: `Paused: complete ${missing.length} details on the portal: ${missing.map((item) => item.label).join(", ")}`, missing };
    if (scope.querySelector('iframe,[role="combobox"],[role="listbox"],[role="radio"]:not(input),[role="checkbox"]:not(input),[role="textbox"]:not(input):not(textarea),[role="switch"],[contenteditable="true"],input[type="password"]') || [...scope.querySelectorAll("*")].some((el) => el.shadowRoot)) return { ready: false, reason: "Embedded forms, custom controls, or account fields require manual review and submission." };
    if (doc.querySelector('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare"],.g-recaptcha,.h-captcha,[data-sitekey]')) return { ready: false, reason: "CAPTCHA detected. Complete verification and submit manually." };
    if (scope.querySelector('[aria-invalid="true"]') || [...scope.querySelectorAll('[role="alert"]')].some((el) => visible(el) && el.textContent.trim())) return { ready: false, reason: "The portal shows an error. Correct it before submitting." };
    const buttons = [...scope.querySelectorAll('button,input[type="submit"],[role="button"]')].filter((button2) => {
      if (!visible(button2)) return false;
      const label = (button2.getAttribute("aria-label") || button2.textContent || button2.value || "").toLowerCase().replace(/\s+/g, " ").trim();
      const exact = /^(submit(?: (?:your )?application)?|send application|complete application|finish application)$/;
      const nativeApply = scope.tagName === "FORM" && /^(apply|apply now)$/.test(label);
      return exact.test(label) || nativeApply;
    });
    if (buttons.length !== 1) return { ready: false, reason: "No unique final Submit button found. For multi-step forms, use Next / Review manually, then scan the final step." };
    const button = buttons[0];
    if (button.disabled || button.getAttribute("aria-disabled") === "true") return { ready: false, reason: "The portal has disabled Submit. Complete its remaining checks." };
    if (scope.tagName === "FORM" && !scope.checkValidity()) return { ready: false, reason: "The portal requires additional valid answers before submission." };
    return { ready: true, button };
  }
  function watchSubmission(doc, scope, options = {}) {
    const host = doc.createElement("div");
    host.id = "resume-assist-progress";
    const shadow = host.attachShadow({ mode: "closed" });
    const style = doc.createElement("style");
    style.textContent = ":host{position:fixed;bottom:20px;right:20px;z-index:2147483647;width:360px;font:13px system-ui;color:#203831}section{padding:16px;background:#f0f5ed;border:1px solid #acc79e;border-radius:12px;box-shadow:0 5px 30px #0003}p{line-height:1.5;margin:8px 0;overflow-wrap:anywhere}button{background:#284f3e;color:white;border:0;border-radius:6px;padding:8px 12px;cursor:pointer}";
    const box = doc.createElement("section");
    const title = doc.createElement("strong");
    title.textContent = "Resume Assist \xB7 automatic submission";
    const message = doc.createElement("p");
    const cancel = doc.createElement("button");
    cancel.textContent = "Cancel automatic submission";
    box.append(title, message, cancel);
    shadow.append(style, box);
    doc.documentElement.append(host);
    let active = true, timer, readySince = null;
    const started = Date.now(), initialUrl = doc.location.href;
    let snapshot = "";
    function stop(text) {
      active = false;
      clearInterval(timer);
      message.textContent = text;
      cancel.textContent = "Dismiss";
      cancel.onclick = () => host.remove();
    }
    function tick() {
      if (!active) return;
      if (Date.now() - started > 6e5 || doc.location.href !== initialUrl || !scope.isConnected) return stop("Stopped: page changed or the 10-minute session expired. Scan again when ready.");
      const result = submissionReadiness(doc, scope, options.allowOptionalBlanks);
      if (!result.ready) {
        readySince = null;
        snapshot = "";
        message.textContent = result.reason;
        return;
      }
      const current = JSON.stringify(collectFields(doc).filter((el) => scope.contains(el)).map((el) => [describeField(el).label, fieldValue(el)]));
      if (current !== snapshot) {
        snapshot = current;
        readySince = null;
      }
      readySince ??= Date.now();
      const remaining = Math.ceil((3e3 - (Date.now() - readySince)) / 1e3);
      if (remaining > 0) {
        message.textContent = `All details complete. Submitting in ${remaining} seconds. Cancel to keep reviewing.`;
        return;
      }
      stop("Submission attempted once. Check the portal for confirmation or errors.");
      result.button.click();
    }
    cancel.onclick = () => stop("Automatic submission cancelled. You can submit manually.");
    timer = setInterval(tick, 250);
    tick();
    return { stop: () => {
      clearInterval(timer);
      active = false;
      host.remove();
    } };
  }

  // src/content.js
  if (!globalThis.__resumeAssistInstalled) {
    globalThis.__resumeAssistInstalled = true;
    let scanned = /* @__PURE__ */ new Map();
    let scope = null;
    let submission = null;
    chrome.runtime.onMessage.addListener((message, sender, respond) => {
      if (sender.id !== chrome.runtime.id) return;
      if (message.type === "RESUME_CANCEL") {
        submission?.stop();
        submission = null;
        respond({ cancelled: true });
        return;
      }
      if (message.type === "RESUME_SCAN") {
        submission?.stop();
        submission = null;
        scanned = /* @__PURE__ */ new Map();
        scope = findScope(document);
        const fields = collectFields(document).filter((element) => !scope || scope.contains(element)).map((element, index) => {
          const id = String(index);
          const { label, key } = describeField(element);
          scanned.set(id, { element, label, key, type: element.type });
          const manual = ["file", "checkbox", "radio"].includes(element.type) || element.multiple || /captcha|one.?time|verification code|social security|passport|bank|credit card|birth/i.test(label);
          const options = element.tagName === "SELECT" ? Array.from(element.options).filter((o) => !o.disabled && o.value).map((o) => ({ value: o.value, label: o.textContent.trim() })) : null;
          return { id, label, key, manual, options, required: isRequired(element), current: fieldValue(element) };
        });
        respond({ fields, embeddedForms: document.querySelectorAll("iframe").length, customControls: document.querySelectorAll('[role="combobox"],[contenteditable="true"]').length });
      }
      if (message.type === "RESUME_FILL") {
        const result = { filled: 0, skipped: 0, manual: [] };
        const visible2 = new Set(collectFields(document));
        for (const [id, previous] of scanned) {
          const { element } = previous;
          if (!visible2.has(element) || fieldValue(element)) {
            result.skipped++;
            continue;
          }
          const { key, label } = describeField(element);
          if (key !== previous.key || label !== previous.label || element.type !== previous.type) {
            result.manual.push(label);
            continue;
          }
          const value = message.answers?.[id] || profileValue(message.profile || {}, key);
          if (writeField(element, value)) result.filled++;
          else result.manual.push(label);
        }
        respond(result);
      }
      if (message.type === "RESUME_AUTOSUBMIT") {
        submission?.stop();
        if (!scope?.isConnected) {
          respond({ armed: false, reason: "No unambiguous application form found. Submit manually." });
          return;
        }
        submission = watchSubmission(document, scope, { allowOptionalBlanks: message.allowOptionalBlanks === true });
        respond({ armed: true });
      }
    });
  }
})();
