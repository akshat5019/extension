(() => {
  // src/forms.js
  var normalize = (text) => String(text || "").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_-]/g, " ").toLowerCase().replace(/\s+/g, " ").trim();
  function classifyField(text, autocomplete = "", type = "") {
    const label = normalize(text);
    if (/password|captcha|one time|verification code|social security|passport|bank|credit card|date of birth|birth date/.test(label)) return null;
    if (/authorized|authorised|authorization|authorisation|sponsor|visa|salary|compensation|gender|race|ethnic|disabilit|veteran|pronoun|relocat|notice period|start date|years|experience|cover letter|why |agree|consent|citizen/.test(label)) return null;
    const auto = {
      "given-name": "firstName",
      "family-name": "lastName",
      name: "fullName",
      email: "email",
      tel: "phone",
      "street-address": "address",
      "address-line1": "address",
      "address-level2": "city",
      "address-level1": "state",
      "postal-code": "postalCode",
      "country-name": "country",
      country: "country",
      organization: "currentCompany",
      "organization-title": "jobTitle"
    };
    const token = autocomplete.split(/\s+/).at(-1);
    if (auto[token]) return auto[token];
    const patterns = [
      ["firstName", /\b(first|given|forename)\s*(name)?\b/],
      ["lastName", /\b(last|family|sur)\s*name\b/],
      ["fullName", /\b(full name|your name|legal name|candidate name)\b|^name$/],
      ["email", /\be ?mail\b/],
      ["phone", /\b(phone|mobile|telephone|contact number)\b/],
      ["linkedin", /linked\s?in/],
      ["github", /github/],
      ["website", /\b(website|portfolio|personal url)\b/],
      ["postalCode", /\b(zip|postal|pin code|pincode)\b/],
      ["city", /\b(city|town)\b/],
      ["state", /\b(state|province|region)\b/],
      ["country", /\bcountry\b/],
      ["address", /\b(street address|home address|residential address|address line 1|address1)\b|^address$/],
      ["currentCompany", /\b(current company|current employer|company name|employer name)\b/],
      ["jobTitle", /\b(current title|current job title|job title|position title)\b/],
      ["school", /\b(school|university|college|institution)\b/],
      ["degree", /\bdegree\b/],
      ["skills", /\bskills\b/]
    ];
    for (const [key, regex] of patterns) if (regex.test(label)) return key;
    if (type === "email") return "email";
    if (type === "tel") return "phone";
    return null;
  }
  function profileValue(profile, key) {
    if (key === "fullName") return [profile.firstName, profile.lastName].filter(Boolean).join(" ");
    return profile[key] || "";
  }
  function describeField(element) {
    const doc = element.ownerDocument;
    const labels = Array.from(element.labels || []).map((label2) => label2.textContent.trim()).filter(Boolean);
    const ariaLabels = (element.getAttribute("aria-labelledby") || "").split(/\s+/).map((id) => doc.getElementById(id)?.textContent || "").filter(Boolean);
    const visibleLabel = labels.join(" ") || ariaLabels.join(" ") || element.getAttribute("aria-label") || element.getAttribute("placeholder");
    const fallback = element.name || element.id || element.getAttribute("autocomplete") || element.type;
    const label = String(visibleLabel || fallback || "Unlabelled field").replace(/\s+/g, " ").trim().slice(0, 240);
    return { label, key: classifyField(visibleLabel || fallback, element.autocomplete, element.type) };
  }
  function collectFields(doc) {
    return Array.from(doc.querySelectorAll("input,select,textarea")).filter((el) => {
      if (el.disabled || el.readOnly || el.closest("[hidden],[inert]") || ["hidden", "submit", "button", "reset", "image", "password"].includes(el.type)) return false;
      const style = doc.defaultView.getComputedStyle(el);
      return style.display !== "none" && style.visibility !== "hidden" && el.getClientRects().length > 0;
    });
  }
  function fieldValue(element) {
    if (["radio", "checkbox"].includes(element.type)) return element.checked ? element.value || "checked" : "";
    if (element.type === "file") return element.files?.length ? "Attached" : "";
    return element.value || "";
  }
  function isRequired(element) {
    return element.required || element.getAttribute("aria-required") === "true" || /\*|\(required\)/i.test(describeField(element).label);
  }
  function writeField(element, value) {
    if (!value || ["file", "checkbox", "radio", "password"].includes(element.type)) return false;
    if (element.tagName === "SELECT") {
      if (element.multiple) return false;
      const match = Array.from(element.options).find((option) => !option.disabled && option.value && (normalize(option.value) === normalize(value) || normalize(option.textContent) === normalize(value)));
      if (!match) return false;
      value = match.value;
    }
    const win = element.ownerDocument.defaultView;
    const prototype = element.tagName === "SELECT" ? win.HTMLSelectElement.prototype : element.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(prototype, "value").set.call(element, value);
    element.dispatchEvent(new win.Event("input", { bubbles: true }));
    element.dispatchEvent(new win.Event("change", { bubbles: true }));
    return element.value === value;
  }

  // src/submission.js
  var visible = (el) => el.getClientRects().length > 0 && el.ownerDocument.defaultView.getComputedStyle(el).visibility !== "hidden";
  function findScope(doc) {
    const fields = collectFields(doc);
    const groups = /* @__PURE__ */ new Map();
    for (const field of fields) {
      const scope = field.closest('[role="dialog"],dialog') || field.form;
      if (scope) groups.set(scope, (groups.get(scope) || 0) + 1);
    }
    const ordered = [...groups].sort((a, b) => b[1] - a[1]);
    if (!ordered.length || ordered[1] && ordered[0][1] === ordered[1][1]) return null;
    return ordered[0][0];
  }
  function submissionReadiness(doc, scope, allowOptionalBlanks = false) {
    if (!scope?.isConnected) return { ready: false, reason: "Application changed. Scan this step again." };
    const fields = collectFields(doc).filter((el) => scope.contains(el));
    if (!fields.length) return { ready: false, reason: "No application fields found. Open the application directly." };
    const missing = [];
    for (const field of fields) {
      const required = isRequired(field);
      let value = fieldValue(field);
      if (field.type === "radio" && field.name) {
        const group = fields.filter((el) => el.type === "radio" && el.name === field.name && el.form === field.form);
        value = group.some((el) => el.checked) ? "Selected" : "";
        if (missing.some((item) => item.radioGroup === field.name)) continue;
      }
      if (!value && (required || !allowOptionalBlanks)) missing.push({ label: describeField(field).label, radioGroup: field.type === "radio" ? field.name : null });
      else if (field.willValidate && !field.checkValidity()) missing.push({ label: `${describeField(field).label} (invalid)` });
    }
    if (missing.length) return { ready: false, reason: `Paused: complete ${missing.length} details on the portal: ${missing.map((item) => item.label).join(", ")}`, missing };
    if (scope.querySelector('iframe,[role="combobox"],[role="listbox"],[role="radio"]:not(input),[role="checkbox"]:not(input),[role="textbox"]:not(input):not(textarea),[role="switch"],[contenteditable="true"],input[type="password"]') || [...scope.querySelectorAll("*")].some((el) => el.shadowRoot)) return { ready: false, reason: "Embedded forms, custom controls, or account fields require manual review and submission." };
    if (doc.querySelector('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare"],.g-recaptcha,.h-captcha,[data-sitekey]')) return { ready: false, reason: "CAPTCHA detected. Complete verification and submit manually." };
    if (scope.querySelector('[aria-invalid="true"]') || [...scope.querySelectorAll('[role="alert"]')].some((el) => visible(el) && el.textContent.trim())) return { ready: false, reason: "The portal shows an error. Correct it before submitting." };
    const buttons = [...scope.querySelectorAll('button,input[type="submit"],[role="button"]')].filter((button2) => {
      if (!visible(button2)) return false;
      const label = (button2.getAttribute("aria-label") || button2.textContent || button2.value || "").toLowerCase().replace(/\s+/g, " ").trim();
      const exact = /^(submit(?: (?:your )?application)?|send application|complete application|finish application)$/;
      const nativeApply = scope.tagName === "FORM" && /^(apply|apply now)$/.test(label);
      return exact.test(label) || nativeApply;
    });
    if (buttons.length !== 1) return { ready: false, reason: "No unique final Submit button found. For multi-step forms, use Next / Review manually, then scan the final step." };
    const button = buttons[0];
    if (button.disabled || button.getAttribute("aria-disabled") === "true") return { ready: false, reason: "The portal has disabled Submit. Complete its remaining checks." };
    if (scope.tagName === "FORM" && !scope.checkValidity()) return { ready: false, reason: "The portal requires additional valid answers before submission." };
    return { ready: true, button };
  }
  function watchSubmission(doc, scope, options = {}) {
    const host = doc.createElement("div");
    host.id = "resume-assist-progress";
    const shadow = host.attachShadow({ mode: "closed" });
    const style = doc.createElement("style");
    style.textContent = ":host{position:fixed;bottom:20px;right:20px;z-index:2147483647;width:360px;font:13px system-ui;color:#203831}section{padding:16px;background:#f0f5ed;border:1px solid #acc79e;border-radius:12px;box-shadow:0 5px 30px #0003}p{line-height:1.5;margin:8px 0;overflow-wrap:anywhere}button{background:#284f3e;color:white;border:0;border-radius:6px;padding:8px 12px;cursor:pointer}";
    const box = doc.createElement("section");
    const title = doc.createElement("strong");
    title.textContent = "Resume Assist \xB7 automatic submission";
    const message = doc.createElement("p");
    const cancel = doc.createElement("button");
    cancel.textContent = "Cancel automatic submission";
    box.append(title, message, cancel);
    shadow.append(style, box);
    doc.documentElement.append(host);
    let active = true, timer, readySince = null;
    const started = Date.now(), initialUrl = doc.location.href;
    let snapshot = "";
    function stop(text) {
      active = false;
      clearInterval(timer);
      message.textContent = text;
      cancel.textContent = "Dismiss";
      cancel.onclick = () => host.remove();
    }
    function tick() {
      if (!active) return;
      if (Date.now() - started > 6e5 || doc.location.href !== initialUrl || !scope.isConnected) return stop("Stopped: page changed or the 10-minute session expired. Scan again when ready.");
      const result = submissionReadiness(doc, scope, options.allowOptionalBlanks);
      if (!result.ready) {
        readySince = null;
        snapshot = "";
        message.textContent = result.reason;
        return;
      }
      const current = JSON.stringify(collectFields(doc).filter((el) => scope.contains(el)).map((el) => [describeField(el).label, fieldValue(el)]));
      if (current !== snapshot) {
        snapshot = current;
        readySince = null;
      }
      readySince ??= Date.now();
      const remaining = Math.ceil((3e3 - (Date.now() - readySince)) / 1e3);
      if (remaining > 0) {
        message.textContent = `All details complete. Submitting in ${remaining} seconds. Cancel to keep reviewing.`;
        return;
      }
      stop("Submission attempted once. Check the portal for confirmation or errors.");
      result.button.click();
    }
    cancel.onclick = () => stop("Automatic submission cancelled. You can submit manually.");
    timer = setInterval(tick, 250);
    tick();
    return { stop: () => {
      clearInterval(timer);
      active = false;
      host.remove();
    } };
  }

  // src/portal.js
  function isResumeUpload(element, file) {
    if (!file || !/\.(pdf|docx|txt)$/i.test(file.name)) return false;
    const labelled = (element.getAttribute("aria-labelledby") || "").split(/\s+/).map((id) => element.ownerDocument.getElementById(id)?.textContent || "").join(" ");
    const nearby = element.parentElement?.tagName === "DIV" ? element.parentElement.textContent.slice(0, 240) : "";
    const text = [...Array.from(element.labels || [], (label) => label.textContent), labelled, nearby, element.getAttribute("aria-label"), element.name, element.id, file.name].filter(Boolean).join(" ");
    return /resume|résumé|curriculum|\bcv\b/i.test(text) && !/cover.?letter|passport|identity|certificate/i.test(text);
  }
  function isApplicationScope(scope) {
    if (!scope || scope.querySelector('input[type="password"]')) return false;
    const text = `${scope.getAttribute("aria-label") || ""} ${scope.textContent || ""}`;
    const resume = [...scope.querySelectorAll('input[type="file"]')].some((input) => isResumeUpload(input, { name: "attachment.pdf" }));
    return resume || /(?:submit|send|complete|finish|job) application|apply (?:for|to) (?:this |a |the )?(?:job|position)/i.test(text);
  }

  // src/content.js
  if (!globalThis.__resumeAssistInstalled) {
    let scanFields = function(preferredScope) {
      submission?.stop();
      submission = null;
      scanned = /* @__PURE__ */ new Map();
      const nextScope = preferredScope || findScope(document);
      if (nextScope !== scope) manualEdits.clear();
      for (const element of manualEdits.keys()) if (!element.isConnected) manualEdits.delete(element);
      scope = nextScope;
      const fields = collectFields(document).filter((element) => !scope || scope.contains(element)).map((element, index) => {
        const id = String(index);
        const { label, key } = describeField(element);
        scanned.set(id, { element, label, key, type: element.type });
        return { id, ...fieldInfo(element) };
      });
      return { fields, embeddedForms: document.querySelectorAll("iframe").length, customControls: document.querySelectorAll('[role="combobox"],[contenteditable="true"]').length };
    }, fillFields = function(profile, answers = {}) {
      const result = { filled: 0, skipped: 0, manual: [], applied: [] };
      const visible2 = new Set(collectFields(document));
      for (const [id, previous] of scanned) {
        const { element } = previous;
        if (!visible2.has(element) || fieldValue(element)) {
          result.skipped++;
          continue;
        }
        const { key, label } = describeField(element);
        if (key !== previous.key || label !== previous.label || element.type !== previous.type) {
          result.manual.push(label);
          continue;
        }
        const value = answers?.[id] || profileValue(profile || {}, key);
        if (writeField(element, value)) {
          result.filled++;
          result.applied.push({ id, ...fieldInfo(element), value });
        } else result.manual.push(label);
      }
      return result;
    }, uploadNotice = function(text, state = "reading") {
      if (!uploadPanel?.host.isConnected) {
        const host = document.createElement("div");
        host.id = "resume-assist-upload";
        const shadow = host.attachShadow({ mode: "closed" });
        const style = document.createElement("style");
        style.textContent = ":host{position:fixed;bottom:20px;left:20px;z-index:2147483647;width:340px;font:13px system-ui;color:#203831}section{padding:16px;background:#f0f5ed;border:1px solid #acc79e;border-radius:12px;box-shadow:0 5px 30px #0003}p{line-height:1.5;margin:8px 0}button{background:#284f3e;color:white;border:0;border-radius:6px;padding:8px 12px;cursor:pointer}";
        const box = document.createElement("section"), title = document.createElement("strong"), message = document.createElement("p"), close = document.createElement("button");
        title.textContent = "Resume Assist \xB7 portal upload";
        close.textContent = "Stop / dismiss";
        close.onclick = () => {
          automaticStopped = true;
          uploadGeneration++;
          clearInterval(uploadTimer);
          host.remove();
        };
        box.append(title, message, close);
        shadow.append(style, box);
        document.documentElement.append(host);
        uploadPanel = { host, message };
      }
      uploadPanel.message.textContent = text;
      uploadPanel.host.dataset.state = state;
    };
    globalThis.__resumeAssistInstalled = true;
    let scanned = /* @__PURE__ */ new Map();
    let scope = null;
    let submission = null;
    const manualEdits = /* @__PURE__ */ new Map();
    let uploadGeneration = 0;
    let uploadTimer;
    let uploadPanel;
    const uploader = Array.from(crypto.getRandomValues(new Uint32Array(4)), (value) => value.toString(16)).join("-");
    const fieldInfo = (element) => {
      const { label, key } = describeField(element);
      const manual = ["file", "checkbox", "radio"].includes(element.type) || element.multiple || /captcha|one.?time|verification code|social security|passport|bank|credit card|birth/i.test(label);
      const options = element.tagName === "SELECT" ? Array.from(element.options).filter((o) => !o.disabled && o.value).map((o) => ({ value: o.value, label: o.textContent.trim() })) : null;
      return { label, key, manual, options, type: element.type, required: isRequired(element), current: fieldValue(element), valid: (!element.willValidate || element.checkValidity()) && element.getAttribute("aria-invalid") !== "true" };
    };
    for (const event of ["input", "change"]) document.addEventListener(event, (event2) => {
      if (event2.isTrusted && [...scanned.values()].some((previous) => previous.element === event2.target && previous.label === describeField(event2.target).label)) {
        const field = fieldInfo(event2.target);
        manualEdits.set(event2.target, { ...field, url: location.href });
        if (event2.type === "change" && field.valid && field.current) chrome.runtime.sendMessage({ type: "PORTAL_SAVE_MANUAL", url: location.href, field, value: field.current }).catch(() => {
        });
      }
    }, true);
    document.addEventListener("change", async (event) => {
      const element = event.target;
      if (!event.isTrusted || element?.type !== "file" || !isResumeUpload(element, element.files?.[0])) return;
      const file = element.files[0], generation = ++uploadGeneration, initialUrl = location.href;
      try {
        if (!(await chrome.runtime.sendMessage({ type: "PORTAL_UPLOAD_ALLOWED" }))?.allowed) return;
        clearInterval(uploadTimer);
        submission?.stop();
        submission = null;
        if (file.size > 10 * 1024 * 1024) throw new Error("Choose a resume smaller than 10 MB.");
        uploadNotice("Reading the resume you attached on this portal. Your original upload continues normally.");
        const data = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result.split(",")[1]);
          reader.onerror = () => reject(new Error("Could not read the attached file."));
          reader.readAsDataURL(file);
        });
        const response = await chrome.runtime.sendMessage({ type: "PORTAL_RESUME_UPLOADED", url: initialUrl, name: file.name, data, uploader, sequence: generation });
        if (generation !== uploadGeneration || location.href !== initialUrl) return;
        if (response?.error) throw new Error(response.error);
        if (!response?.profile) throw new Error("Resume parser did not respond. Reload the extension and try again.");
        const applicationScope = element.closest('[role="dialog"],dialog') || element.form || findScope(document);
        if (!applicationScope) {
          uploadNotice("Resume read. Open Resume Assist to review the detected profile and scan this form manually.", "complete");
          return;
        }
        let filled = 0;
        const until = Date.now() + 3e4;
        const fill = () => {
          if (generation !== uploadGeneration || location.href !== initialUrl || !applicationScope.isConnected) {
            clearInterval(uploadTimer);
            return;
          }
          const scannedPage = scanFields(applicationScope);
          filled += fillFields(response.profile).filled;
          const missing = scannedPage.fields.filter((field) => !fieldValue(scanned.get(field.id).element)).length;
          uploadNotice(`Filled ${filled} details from your portal resume. ${missing} fields still need your attention. Review the form; use Resume Assist for missing answers. Automatic submission needs separate approval.`, "complete");
          if (Date.now() >= until) {
            clearInterval(uploadTimer);
            uploadTimer = null;
          }
        };
        fill();
        uploadTimer = setInterval(fill, 500);
      } catch (error) {
        if (generation === uploadGeneration) uploadNotice(error.message || "Could not read the attached resume. Enter details manually.", "error");
      }
    }, true);
    let automaticScope = null, automaticUrl = "", automaticFields = /* @__PURE__ */ new Set(), automaticBusy = false, automaticStopped = false;
    let automaticTimer;
    async function reuseProfile() {
      if (automaticBusy || automaticStopped || submission || uploadTimer) return;
      const candidate = findScope(document);
      if (!isApplicationScope(candidate)) return;
      const fields = collectFields(document).filter((element) => candidate.contains(element));
      if (candidate === automaticScope && automaticUrl === location.href && fields.every((element) => automaticFields.has(element))) return;
      automaticBusy = true;
      const url = location.href;
      try {
        const result = await chrome.runtime.sendMessage({ type: "PORTAL_PROFILE", url });
        if (!result?.profile || location.href !== url || !candidate.isConnected || submission || automaticStopped) return;
        automaticScope = candidate;
        automaticUrl = url;
        automaticFields = new Set(fields);
        scanFields(candidate);
        const filled = fillFields(result.profile).filled;
        const missing = [...scanned.values()].filter(({ element }) => !fieldValue(element)).length;
        uploadNotice(`Filled ${filled} saved details. ${missing ? `Paused: complete ${missing} missing fields manually.` : "Review your application."} Valid manual answers are remembered when you leave a field if remembering is enabled.`, "complete");
      } catch {
      } finally {
        automaticBusy = false;
      }
    }
    new MutationObserver(() => {
      clearTimeout(automaticTimer);
      automaticTimer = setTimeout(reuseProfile, 300);
    }).observe(document.documentElement, { childList: true, subtree: true });
    reuseProfile();
    setInterval(reuseProfile, 1500);
    chrome.runtime.onMessage.addListener((message, sender, respond) => {
      if (sender.id !== chrome.runtime.id) return;
      if (message.type === "RESUME_MANUAL_ANSWERS") {
        const visible2 = new Set(collectFields(document));
        const fields = [...manualEdits].filter(([element, previous]) => visible2.has(element) && previous.url === location.href && previous.label === describeField(element).label && previous.type === element.type && (!scope || scope.contains(element)) && (!element.willValidate || element.checkValidity())).map(([element]) => ({ ...fieldInfo(element), value: fieldValue(element) }));
        respond({ fields, origin: location.origin });
        return;
      }
      if (message.type === "RESUME_CANCEL") {
        automaticStopped = true;
        submission?.stop();
        submission = null;
        uploadGeneration++;
        clearInterval(uploadTimer);
        respond({ cancelled: true });
        return;
      }
      if (message.type === "RESUME_SCAN") {
        automaticStopped = true;
        uploadGeneration++;
        clearInterval(uploadTimer);
        respond(scanFields());
      }
      if (message.type === "RESUME_FILL") {
        respond(fillFields(message.profile, message.answers));
      }
      if (message.type === "RESUME_AUTOSUBMIT") {
        submission?.stop();
        if (!scope?.isConnected) {
          respond({ armed: false, reason: "No unambiguous application form found. Submit manually." });
          return;
        }
        submission = watchSubmission(document, scope, { allowOptionalBlanks: message.allowOptionalBlanks === true });
        respond({ armed: true });
      }
    });
  }
})();
